/**
 * 
 */
/**
 * 
 */
module LibraryManagement {
	requires java.desktop;
}